import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='alk272',
    application_name='dfs-web-app',
    app_uid='t9FFMKH4SwnPRqndc9',
    org_uid='3d8fcba4-af3d-47f0-84cc-e78c4ffb51d0',
    deployment_uid='5cbc7fc6-044d-423e-a752-fc8e8f2ffa55',
    service_name='dfs-web',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='4.5.3',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'dfs-web-dev-hello', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('handler.hello')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
